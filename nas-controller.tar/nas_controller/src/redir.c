#ifndef __REDIR_C__
#define __REDIR_C__

#include <sys/stat.h>
#include <type.h>
#include <common.h>
#include <redir.h>

/********************************************************************
 *  Global Instance Declaration
 ********************************************************************/
redir_ctx_t redir_ctx_g;

/********************************************************************
 * Function Definition starts
 ********************************************************************/
int32_t redir_recv(int32_t fd, 
                   uint8_t *packet_ptr, 
                   uint16_t *packet_length) {
  int32_t  ret = -1;
  uint16_t max_length = 1500;
  do {
    ret = recv(fd, packet_ptr, max_length, 0);

  }while((ret == -1) && (EINTR == errno));

  *packet_length = (uint16_t)ret;
  return(ret);

}/*redir_recv*/

int32_t redir_send(int32_t fd, 
                   uint8_t *packet_ptr, 
                   uint16_t packet_length) {
  int32_t  ret = -1;
  do {
    ret = send(fd, packet_ptr, packet_length, 0);

  }while((ret == -1) && (EINTR == errno));

  return(ret);

}/*redir_send*/

void redir_swap(uint32_t *a, uint32_t *b) {
  uint32_t t = *a;
  *a = *b;
  *b = t;

}/*redir_swap*/

uint32_t redir_partition (redir_session_t *session, int16_t low, int16_t high) {
  int16_t i;
  int16_t j;
  uint32_t pivot = session[low].conn;  
  i = low;
  j = high + 1;

  while( 1)
  {
    do ++i; while(session[i].conn >= pivot && i <= high);
    do --j; while(session[j].conn < pivot);

    if(i >= j) break;
    redir_swap(&session[i].conn, &session[j].conn);
  } 

  redir_swap(&session[low].conn, &session[j].conn);
  return(j);
  
}/*redir_partion*/

/* low  --> Starting index,  high  --> Ending index */
void redir_quick_sort(redir_session_t *session, int16_t low_idx, int16_t high_idx) {
  uint32_t pi;

  if (low_idx < high_idx) {
    /* pi is partitioning index, arr[p] is now
       at right place */
    pi = redir_partition(session, low_idx, high_idx);

    redir_quick_sort(session, low_idx, pi - 1);
    redir_quick_sort(session, pi + 1, high_idx);
  }

}/*redir_quick_sort*/

void redir_modify_conn_count(redir_session_t *session) {

  uint32_t idx;
  redir_ctx_t *pRedirCtx = &redir_ctx_g;

  for(idx = 0; idx < pRedirCtx->session_count; idx++) {
    if(!session[idx].conn) {
      if(!idx) {
        pRedirCtx->session_count = idx;
      } else {
        pRedirCtx->session_count = idx - 1;
      }
      break;
    }
  }

}/*redir_modify_conn_count*/

int32_t redir_parse_req(uint32_t con_fd,
                        uint8_t *packet_ptr,
                        uint16_t packet_length) {

  uint8_t *line_ptr;
  uint8_t *tmp_ptr = NULL;
  uint16_t idx = 0;
  uint8_t method[8];
  uint8_t *uri_ptr;
  uint16_t uri_len;
  uint8_t protocol[8];
  uint16_t tmp_len = 0;
  uint16_t line_len = 0;

  redir_ctx_t *pRedirCtx = &redir_ctx_g;

  tmp_ptr = (uint8_t *)malloc(packet_length);

  if(NULL == tmp_ptr) {
    fprintf(stderr, "\n%s:%d Allocation of Memory failed\n", __FILE__, __LINE__);
    return(-1);
  }

  memset((void *)tmp_ptr, 0, packet_length);
  memcpy(tmp_ptr, packet_ptr, packet_length);

  line_ptr = strtok(tmp_ptr, "\r\n");

  sscanf((const char *)line_ptr, 
         "%s %*s %s", 
         method, 
         protocol);

  uri_len = strlen((const char *)line_ptr) - 
            (strlen((const char *)method) + 
             strlen((const char *)protocol));

  uri_ptr = (uint8_t *) malloc(uri_len);

  if(NULL == uri_ptr) {
    fprintf(stderr, "\n%s:%d Memory Allocation Failed\n", __FILE__, __LINE__);
    free(tmp_ptr);
    return(-1);
  }

  memset((void *)uri_ptr, 0, uri_len);
  sscanf((const char *)line_ptr, 
         "%*s %s %*s", 
         uri_ptr);

  memset((void *)pRedirCtx->session[con_fd].method, 0, sizeof(pRedirCtx->session[con_fd].method));
  memset((void *)pRedirCtx->session[con_fd].protocol, 0, sizeof(pRedirCtx->session[con_fd].protocol));
  memset((void *)pRedirCtx->session[con_fd].uri, 0, sizeof(pRedirCtx->session[con_fd].uri));

  strncpy(pRedirCtx->session[con_fd].method, method, strlen((const char *)method));
  strncpy(pRedirCtx->session[con_fd].protocol, protocol, strlen((const char *)protocol));
  strncpy(pRedirCtx->session[con_fd].uri, uri_ptr, strlen((const char *)uri_ptr));

  free(uri_ptr);
  uri_ptr = NULL;

  memset((void *)pRedirCtx->session[con_fd].mime_header, 0, sizeof(pRedirCtx->session[con_fd].mime_header));

  while((line_ptr = strtok(NULL, "\r\n"))) { 
    sscanf((const char *)line_ptr, 
           "%[^:]:%*s",
           pRedirCtx->session[con_fd].mime_header[idx][0]);

    tmp_len = strlen((const char *)pRedirCtx->session[con_fd].mime_header[idx][0]);
    line_len = strlen((const char *)line_ptr);

    /*If Method is POST then Payload would be followed by an empty line \r\n*/
    if(line_len > tmp_len) {
      memcpy((void *)&pRedirCtx->session[con_fd].mime_header[idx][1], 
             (void *)&line_ptr[tmp_len + 2], 
             (line_len - (tmp_len + 2)));
      idx++;
    }
  }

  pRedirCtx->session[con_fd].mime_header_count = idx - 1;
  free(tmp_ptr);
 
  return(0);  
}/*redir_parse_req*/

int32_t redir_process_image_req(uint16_t image_name, 
                                uint8_t *response_ptr, 
                                uint16_t *response_len_ptr) {
  uint32_t fd;
  struct stat statbuff;

  if(1 == image_name) {

    fd = open("../img/wait.gif", O_RDONLY);

    if(fd > 0) {
      fstat(fd, &statbuff);
      *response_len_ptr = read(fd, response_ptr, statbuff.st_size);
      close(fd);
    }
  }
  return(0);
 
}/*redir_process_image_req*/

int32_t redir_process_login_req(uint16_t htmp_page_req, 
                                uint8_t *response_ptr, 
                                uint16_t *response_len_ptr) {
  uint8_t html_body[255];
  uint16_t html_body_len;

  memset((void *)html_body, 0, sizeof(html_body));
  html_body_len = snprintf((char *)html_body, 
                           sizeof(html_body),
                           "%s%s",
                           "<html><head><title></title></head>",
                           "<body><img src=../img/wait.gif></body></html>"); 

  *response_len_ptr = sprintf((char *)response_ptr,
                              "%s%s%s%d%s"
                              "%s",
                              "HTTP/1.1 200 OK\r\n",
                              "Content-Type: text/html\r\n",
                              "Content-Length: ",
                              html_body_len,
                              "\r\n\r\n",
                              html_body);

  *response_len_ptr += html_body_len; 
  return(0);

}/*redir_process_login_req*/

int32_t redir_process_uri(uint32_t con_fd,
                          uint8_t *response_ptr,
                          uint16_t *response_len_ptr) {
  uint16_t idx;
  uint8_t *referer_ptr;
  uint16_t referer_len;

  redir_ctx_t *pRedirCtx = &redir_ctx_g;

  if(!strncmp(pRedirCtx->session[con_fd].uri, "/img/wait.gif", 13)) {
    redir_process_image_req(1, response_ptr, response_len_ptr);

  } else if(!strncmp(pRedirCtx->session[con_fd].uri, "/login.html",11)) {
    redir_process_login_req(2, response_ptr, response_len_ptr);
    
  } else {

    for(idx = 0; idx < pRedirCtx->session[con_fd].mime_header_count; idx++) {

      if(!strncmp((const char *)pRedirCtx->session[con_fd].mime_header[idx][0], "Host", 4)) {

        referer_len = strlen((const char *)pRedirCtx->session[con_fd].mime_header[idx][1]) +
                      strlen((const char *)pRedirCtx->session[con_fd].uri) + 50;

        referer_ptr = (uint8_t *)malloc(referer_len);

        if(NULL == referer_ptr) {
          fprintf(stderr, "\n%s:%d Memory Allocation Failed\n", __FILE__, __LINE__);
          return(-1);
        }
  
        memset((void *)referer_ptr, 0, referer_len); 
        snprintf((char *)referer_ptr, 
                 referer_len,
                 "%s%s%s",
                 "Referer: http://",
                 pRedirCtx->session[con_fd].mime_header[idx][1],
                 pRedirCtx->session[con_fd].uri);
        break;
      } 
    }
  
    if(idx == pRedirCtx->session[con_fd].mime_header_count) {
      fprintf(stderr, "\n%s:%d Host Header not found in mime header\n", __FILE__, __LINE__);
      return(-1);
    }

    *response_len_ptr = sprintf((char *)response_ptr, 
                            "%s%s%s%s%s"
                            "%s%s%s%d%s"
                            "%s%s%s%s%s"
                            "%s",
                            "HTTP/1.1 302 Moved Temporarily\r\n",
                            referer_ptr,
                            "\r\n",
                            "Connection: Keep-Alive\r\n",
                            "Location: ",
                            "http://",
                            pRedirCtx->uam_ip,
                            ":",
                            pRedirCtx->uam_port,
                            "/login.html\r\n",
                            "Content-Type: text/html\r\n",
                            "Accept-Language: en-US,en;q=0.5\r\n",
                            "Accept: text/*;q=0.3, text/html;q=0.7, text/html;level=1,",
                            "text/html;level=2;q=0.4, */*;q=0.5\r\n",
                            "Content-Length: 0",
                            /*Delimiter B/W Header and Body*/
                            "\r\n\r\n");

    free(referer_ptr);
    referer_ptr = NULL;
  }
  return(0);

}/*redir_process_uri*/
                          
int32_t redir_process_req(uint32_t con_fd, 
                          uint8_t *packet_ptr, 
                          uint16_t packet_length) {

  /*Build temporary HTTP Response*/
  uint8_t http_redir[1500];
  uint16_t http_len;
  uint16_t idx;

  redir_ctx_t *pRedirCtx = &redir_ctx_g;

  fprintf(stderr, "\n%s:%d Received Req is \n%s\n", __FILE__, __LINE__, packet_ptr);
  redir_parse_req(con_fd, packet_ptr, packet_length);
#if 0
  for(idx = 0; idx < pRedirCtx->mime_header_count; idx++)
    fprintf(stderr, "\n%s:%d mime_header %s - %s\n", 
                    __FILE__, 
                    __LINE__, 
                    pRedirCtx->mime_header[idx][0],
                    pRedirCtx->mime_header[idx][1]);
#endif

  memset((void *)http_redir, 0, sizeof(http_redir));
  redir_process_uri(con_fd, http_redir, &http_len);

  if(redir_send(con_fd, http_redir, http_len) < 0) {
    perror("redir send Failed:");
    return(-1); 
  }
  return(0);

}/*redir_process_req*/

int32_t redir_init(uint32_t redir_listen_ip, 
                   uint16_t redir_listen_port, 
                   uint8_t *uam_ip, 
                   uint16_t uam_port) {

  int32_t fd = -1;
  struct sockaddr_in redir_addr;
  size_t redir_addr_len;
  redir_ctx_t *pRedirCtx = &redir_ctx_g;

  fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  if(fd < 0) {
    fprintf(stderr, "\n%s:%d creation of socket failed\n", __FILE__, __LINE__);
    return(-1);
  }
  redir_addr_len = sizeof(struct sockaddr_in);
  redir_addr.sin_addr.s_addr = htonl(redir_listen_ip);
  redir_addr.sin_port = htons(redir_listen_port);
  redir_addr.sin_family = AF_INET;
  memset((void *)redir_addr.sin_zero, 0, sizeof(redir_addr.sin_zero));

  if(bind(fd, (struct sockaddr *)&redir_addr, redir_addr_len) < 0) {
    fprintf(stderr, "\n%s:%d bind to given address failed\n", __FILE__, __LINE__);
    perror("Bind Failed: ");
    return(-1);
  }
  
  /*Max Pending connection which is 10 as of now*/
  if(listen(fd, 10) < 0) {
    fprintf(stderr, "\n%s:%d listen to given ip failed\n", __FILE__, __LINE__);
    return(-1);
  }

  pRedirCtx->redir_listen_ip = redir_listen_ip;
  pRedirCtx->redir_listen_port = redir_listen_port;
  strncpy(pRedirCtx->uam_ip, uam_ip, strlen((const char *)uam_ip));
  pRedirCtx->uam_port = uam_port;
  pRedirCtx->redir_fd = fd;

  memset((void *)pRedirCtx->session, 0, sizeof(pRedirCtx->session));
  pRedirCtx->session_count = 0;

  return(0); 
}/*redir_init*/

/* @brief This function is the entry point of thread for Redirect
 *
 * @param1 pointer to void received while spawning the thread.
 *
 * @return pointer to void
 */
void *redir_main(void *argv) {

  redir_ctx_t *pRedirCtx = &redir_ctx_g;
  int32_t ret;
  int32_t new_conn;
  struct timeval to;
  struct sockaddr_in peer_addr;
  uint16_t idx;
  size_t peer_addr_len;
  uint8_t packet_buffer[3500];
  uint16_t packet_length;
  
  for(;;) {
    to.tv_sec = 2;
    to.tv_usec = 0;
    
    FD_ZERO(&pRedirCtx->rd);
    FD_SET(pRedirCtx->redir_fd, &pRedirCtx->rd);

    for(idx = 0; idx < pRedirCtx->session_count; idx++) {
      FD_SET(pRedirCtx->session[idx].conn, &pRedirCtx->rd);
    } 
   
    pRedirCtx->max_fd = (pRedirCtx->redir_fd > pRedirCtx->session[0].conn ? 
                         pRedirCtx->redir_fd : 
                         pRedirCtx->session[0].conn) + 1;

    ret = select(pRedirCtx->max_fd, &pRedirCtx->rd, NULL, NULL, &to);
   
    if(ret > 0) {

      if(FD_ISSET(pRedirCtx->redir_fd, &pRedirCtx->rd)) {
        /*New Connection accept it.*/
        new_conn = accept(pRedirCtx->redir_fd, 
                          (struct sockaddr *)&peer_addr, 
                          (socklen_t *)&peer_addr_len);

        pRedirCtx->session[pRedirCtx->session_count].peer_addr = peer_addr;
        pRedirCtx->session[pRedirCtx->session_count++].conn = new_conn;

        redir_quick_sort(pRedirCtx->session, 
                         (int16_t)0, 
                         (int16_t)(pRedirCtx->session_count - 1));

      } else {

        for(idx = 0; idx < pRedirCtx->session_count; idx++) {
          if(FD_ISSET(pRedirCtx->session[idx].conn, &pRedirCtx->rd)) {
            /*Either connection is closed or data has been received.*/
            memset((void *)packet_buffer, 0, sizeof(packet_buffer));
            packet_length = 0;
            redir_recv(pRedirCtx->session[idx].conn, packet_buffer, &packet_length);

            if(!packet_length) {
              /*Closing the connected conn_id*/
              close(pRedirCtx->session[idx].conn);
              pRedirCtx->session[idx].conn = 0;
              redir_quick_sort(pRedirCtx->session, 
                               (int16_t)0, 
                               (int16_t)(pRedirCtx->session_count - 1));
              redir_modify_conn_count(pRedirCtx->session);

            } else {
              redir_process_req(pRedirCtx->session[idx].conn, 
                                packet_buffer, 
                                packet_length);
            }
          }  
        }
      }
    } else if(!ret) {
      //fprintf(stderr, "\n%s:%d Got the timeout\n", __FILE__, __LINE__);
    }
  }
  
}/*redir_main*/

#endif /* __REDIR_C__ */
