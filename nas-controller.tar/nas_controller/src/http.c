#ifndef __HTTP_C__
#define __HTTP_C__

#include <sys/stat.h>
#include <type.h>
#include <common.h>
#include <http.h>

/********************************************************************
 *  Global Instance Declaration
 ********************************************************************/
http_ctx_t g_http_ctx;

/********************************************************************
 * Function Definition starts
 ********************************************************************/
int32_t http_recv(int32_t fd, 
                   uint8_t *packet_ptr, 
                   uint16_t *packet_length) {
  int32_t  ret = -1;
  uint16_t max_length = 3000;
  do {
    ret = recv(fd, packet_ptr, max_length, 0);

  }while((ret == -1) && (EINTR == errno));

  *packet_length = (uint16_t)ret;
  return(ret);

}/*http_recv*/

int32_t http_send(int32_t fd, 
                   uint8_t *packet_ptr, 
                   uint16_t packet_length) {
  int32_t  ret = -1;
  uint16_t offset = 0;
  do {
    ret = send(fd, (void *)&packet_ptr[offset], (packet_length - offset), 0);
    
    offset += ret;
    if(!(packet_length - offset)) {
      ret = 0;
    }

  }while(ret);

  return(offset);

}/*http_send*/

void http_swap(uint32_t *a, uint32_t *b) {
  uint32_t t = *a;
  *a = *b;
  *b = t;

}/*http_swap*/

uint32_t http_partition (http_session_t *session, int16_t low, int16_t high) {
  int16_t i;
  int16_t j;
  uint32_t pivot = session[low].conn;  
  i = low;
  j = high + 1;

  while( 1)
  {
    do ++i; while( session[i].conn >= pivot && i <= high );
    do --j; while( session[j].conn < pivot );
    if( i >= j ) break;
    http_swap(&session[i].conn, &session[j].conn);
  } 

  http_swap(&session[low].conn, &session[j].conn);
  return(j);
  
}/*http_partion*/

/* low  --> Starting index,  high  --> Ending index */
void http_quick_sort(http_session_t *session, int16_t low_idx, int16_t high_idx) {
  uint32_t pi;

  if (low_idx < high_idx) {
    /* pi is partitioning index, arr[p] is now
       at right place */
    pi = http_partition(session, low_idx, high_idx);

    http_quick_sort(session, low_idx, pi - 1);
    http_quick_sort(session, pi + 1, high_idx);
  }

}/*http_quick_sort*/

void http_modify_conn_count(http_session_t *session) {

  uint32_t idx;
  http_ctx_t *pHttpCtx = &g_http_ctx;

  for(idx = 0; idx < pHttpCtx->session_count; idx++) {
    if(!session[idx].conn) {
      if(!idx) {
        pHttpCtx->session_count = idx;
      } else {
        pHttpCtx->session_count = idx - 1;
      }
      break;
    }
  }

}/*http_modify_conn_count*/

int32_t http_is_connection_closed(uint32_t con_fd) {
  http_ctx_t *pHttpCtx = &g_http_ctx;
  uint16_t idx;

  for(idx = 0; idx < pHttpCtx->session[con_fd].mime_header_count; idx++) {
    if((!strncmp(pHttpCtx->session[con_fd].mime_header[idx][0], "Connection", 10)) &&
       (!strncmp(pHttpCtx->session[con_fd].mime_header[idx][1], "close", 5))) {
      return(1);
    }  
  }
  return(0);
}/*http_is_connection_closed*/

int32_t http_parse_req(uint32_t con_fd,
                        uint8_t *packet_ptr,
                        uint16_t packet_length) {

  uint8_t *line_ptr;
  uint8_t *tmp_ptr = NULL;
  uint16_t idx = 0;
  uint8_t method[8];
  uint8_t *uri_ptr;
  uint16_t uri_len;
  uint8_t protocol[8];
  uint16_t tmp_len;
  uint16_t line_len;

  http_ctx_t *pHttpCtx = &g_http_ctx;

  tmp_ptr = (uint8_t *)malloc(packet_length);

  if(NULL == tmp_ptr) {
    fprintf(stderr, "\n%s:%d Allocation of Memory failed\n", __FILE__, __LINE__);
    return(-1);
  }

  memset((void *)tmp_ptr, 0, packet_length);
  memcpy(tmp_ptr, packet_ptr, packet_length);

  line_ptr = strtok(tmp_ptr, "\r\n");

  sscanf((const char *)line_ptr, 
         "%s %*s %s", 
         method, 
         protocol);

  uri_len = strlen((const char *)line_ptr) - 
            (strlen((const char *)method) + 
             strlen((const char *)protocol));

  uri_ptr = (uint8_t *) malloc(uri_len);

  if(NULL == uri_ptr) {
    fprintf(stderr, "\n%s:%d Memory Allocation Failed\n", __FILE__, __LINE__);
    free(tmp_ptr);
    return(-1);
  }

  memset((void *)uri_ptr, 0, uri_len);
  sscanf((const char *)line_ptr, 
         "%*s %s %*s", 
         uri_ptr);

  memset((void *)pHttpCtx->session[con_fd].method, 0, sizeof(pHttpCtx->session[con_fd].method));
  memset((void *)pHttpCtx->session[con_fd].protocol, 0, sizeof(pHttpCtx->session[con_fd].protocol));
  memset((void *)pHttpCtx->session[con_fd].uri, 0, sizeof(pHttpCtx->session[con_fd].uri));

  strncpy(pHttpCtx->session[con_fd].method, method, strlen((const char *)method));
  strncpy(pHttpCtx->session[con_fd].protocol, protocol, strlen((const char *)protocol));
  strncpy(pHttpCtx->session[con_fd].uri, uri_ptr, strlen((const char *)uri_ptr));

  free(uri_ptr);
  uri_ptr = NULL;

  memset((void *)pHttpCtx->session[con_fd].mime_header, 0, sizeof(pHttpCtx->session[con_fd].mime_header));
  pHttpCtx->session[con_fd].mime_header_count = 0;

  while((line_ptr = strtok(NULL, "\r\n"))) { 

    sscanf((const char *)line_ptr, 
           "%[^:]:%*s",
           pHttpCtx->session[con_fd].mime_header[idx][0]);

    tmp_len = strlen((const char *)pHttpCtx->session[con_fd].mime_header[idx][0]);
    line_len = strlen((const char *)line_ptr);

    if(line_len > tmp_len) {
      memcpy((void *)&pHttpCtx->session[con_fd].mime_header[idx][1], 
             (const void *)&line_ptr[tmp_len + 2], 
             (line_len - (tmp_len + 2)));
      idx++;
    }
  }

  pHttpCtx->session[con_fd].mime_header_count = idx - 1;

  free(tmp_ptr);
  tmp_ptr = NULL;

  if(http_is_connection_closed(con_fd)) {
    fprintf(stderr, "\n%s:%d HTTP Connection is closed\n", __FILE__, __LINE__);
    return(1);
  }
 
  return(0);  
}/*http_parse_req*/

int32_t http_process_image_req(uint32_t con_fd,
                               uint8_t **response_ptr, 
                               uint16_t *response_len_ptr) {
  uint32_t fd;
  struct stat statbuff;
  uint8_t http_header[255];
  uint8_t file_name[255];
  uint16_t tmp_len;
  http_ctx_t *pHttpCtx = &g_http_ctx;

  memset((void *)file_name, 0, sizeof(file_name));
 
  snprintf((char *)file_name, sizeof(file_name),
           "..%s",
           pHttpCtx->session[con_fd].uri);
  
  fd = open(file_name, O_RDONLY);

  if(fd > 0) {
    fstat(fd, &statbuff);
    tmp_len = snprintf((char *)http_header,
                       sizeof(http_header), 
                       "%s%s%s%d%s"
                       "%s%s",
                       "HTTP/1.1 200 OK\r\n",
                       "Content-Type: image/gif; image/png;image/ico\r\n",
                       "Content-Length: ",
                       (int32_t)statbuff.st_size,
                       "\r\n",
                       "Connection: Keep-Alive\r\n",
                       "\r\n");

    (*response_ptr) = (uint8_t *)malloc(statbuff.st_size + tmp_len);

    if(!(*response_ptr)) {
      fprintf(stderr, "\n%s:%d memory Allocation Failed\n", __FILE__, __LINE__);
      return(-1);
    }

    memset((void *)(*response_ptr), 0, (statbuff.st_size + tmp_len));
    memcpy((void *)(*response_ptr), (const void *)http_header, tmp_len);

    *response_len_ptr = read(fd, (void *)&(*response_ptr)[tmp_len], statbuff.st_size);
    *response_len_ptr += tmp_len;

    fprintf(stderr, "\n%s:%d Image Response Length is %d file size %d html body len %d\n", 
                    __FILE__, 
                    __LINE__, 
                    *response_len_ptr, 
                    (int32_t)statbuff.st_size,
                    tmp_len);
    close(fd);
  }
  return(0);
 
}/*http_process_image_req*/


int32_t http_process_login_req(uint8_t **response_ptr, 
                               uint16_t *response_len_ptr) {
  uint8_t html_body[255];
  uint16_t html_body_len;
  int32_t ret = -1;

  memset((void *)html_body, 0, sizeof(html_body));

  html_body_len = snprintf((char *)html_body, 
                           sizeof(html_body),
                           "%s%s%s%s%s"
                           "%s%s",
                           "<html><head><title></title>",
                           "<meta http-equiv=\"refresh\" content=\"1;URL='/ui.html'\"",
                           "</head>",
                           "<body><center><table align = center style =\"position:relative; margin-top:10%\">",
                           "<tr><td align=center>",
                           "<img src=../img/wait.gif>",
                           "</td></tr></table></center></body></html>"); 

  (*response_ptr) = (uint8_t *)malloc(html_body_len + 255);

  if(!(*response_ptr)) {
    fprintf(stderr, "\n%s:%d Memory Allocation Failed\n", __FILE__, __LINE__);
    return(-1);
  }

  memset((void *)(*response_ptr), 0, (255 + html_body_len));

  ret = snprintf((char *)(*response_ptr),
                 (255 + html_body_len),
                 "%s%s%s%s%d"
                 "%s",
                 "HTTP/1.1 200 OK\r\n",
                 "Content-Type: text/html\r\n",
                 "Connection: Keep-Alive\r\n",
                 "Content-Length: ",
                 html_body_len,
                 "\r\n\r\n");
  memcpy((void *)&(*response_ptr)[ret], (const void *)html_body, html_body_len);

  *response_len_ptr = ret + html_body_len; 

  return(0);

}/*http_process_login_req*/


int32_t http_process_ui_req(uint8_t **response_ptr, 
                            uint16_t *response_len_ptr) {

  uint8_t html_body[1<<15];
  uint16_t html_body_len;
  int32_t ret = -1;

  memset((void *)html_body, 0, sizeof(html_body));

  html_body_len = snprintf((char *)html_body, 
                           sizeof(html_body),
                           "%s%s%s%s%s"
                           "%s%s%s%s%s"
                           "%s%s%s%s%s"
                           "%s%s%s",
                           "<html><head><title></title>",
                           /*For Responsive Web Page*/
                           "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">",
                           "</head>",
                           "<body><center><table>",
                           "<tr><form method=GET action=/sign_in_register.html>",
                           "<td><input type=email name=email_id placeholder=\"E-mail id\"></td>",
                           "</tr><tr><td><input type=password name=password placeholder=\"Password\"></td>",
                           "</tr><tr><td><input type=submit value=\"Sign in\">",
                           "<input type=submit value=\"Register\"></td></tr></form>",
                           "<tr><td><input type=button name=or value=\"OR\" disabled></td>",
                           "</tr><tr><form method GET action=/login_with_mobile_no.html>",
                           "<td><input type=text name=mobile_no placeholder=\"10 digits Mobile Number\"></td>",
                           "</tr><tr><td><input type=submit value=\"Sign in\"></td></tr></form>",
                           /*Image Logog starts*/
                           "<tr><td><img src=../img/1x/btn_google_signin_dark_normal_web.png></td></tr>",
                           "<tr><td><img src=../img/sign-in-with-twitter-gray.png></td></tr>",
                           /*Logo Dimension is gouverned by face book*/
                           "<tr><td><img src=../img/fb_logo.png height=28px width=200px></td></tr>",
                           "<tr><td><img src=../img/aadhaar-logo_en-GB.png></tr></td>",
                           "</table></center></body></html>"); 

  (*response_ptr) = (uint8_t *)malloc(html_body_len + 255/*For Http Header*/);

  if(!(*response_ptr)) {
    fprintf(stderr, "\n%s:%d Memory Allocation Failed\n", __FILE__, __LINE__);
    return(-1);
  }

  memset((void *)(*response_ptr), 0, (255 + html_body_len));

  ret = snprintf((char *)(*response_ptr),
                 (255 + html_body_len),
                 "%s%s%s%s%d"
                 "%s",
                 "HTTP/1.1 200 OK\r\n",
                 "Content-Type: text/html\r\n",
                 "Connection: Keep-Alive\r\n",
                 "Content-Length: ",
                 html_body_len,
                 "\r\n\r\n");
  memcpy((void *)&(*response_ptr)[ret], (const void *)html_body, html_body_len);

  *response_len_ptr = ret + html_body_len; 

  return(0);
}/*http_process_ui_req*/


int32_t http_process_sign_in_register_req(uint8_t **response_ptr, 
                                          uint16_t *response_len_ptr) {

  return(0);

}/*http_process_sign_in_register_req*/


int32_t http_process_login_with_mobile_no_req(uint8_t **response_ptr, 
                                              uint16_t *response_len_ptr) {


  return(0);

}/*http_process_login_with_mobile_no_req*/


int32_t http_process_uri(uint32_t con_fd,
                         uint8_t **response_ptr,
                         uint16_t *response_len_ptr) {

  http_ctx_t *pHttpCtx = &g_http_ctx;

  if(!strncmp(pHttpCtx->session[con_fd].uri, "/img", 4)) {

    http_process_image_req(con_fd, response_ptr, response_len_ptr);

  } else if(!strncmp(pHttpCtx->session[con_fd].uri, "/login.html", 11)) {

    http_process_login_req(response_ptr, response_len_ptr);

  } else if(!strncmp(pHttpCtx->session[con_fd].uri, "/ui.html", 8)) {

    http_process_ui_req(response_ptr, response_len_ptr);
  
  } else if(!strncmp(pHttpCtx->session[con_fd].uri, "/sign_in_register.html", 22)) {

    http_process_sign_in_register_req(response_ptr, response_len_ptr);

  } else if(!strncmp(pHttpCtx->session[con_fd].uri, "/login_with_mobile_no.html", 26)) {

    http_process_login_with_mobile_no_req(response_ptr, response_len_ptr);

  } else {

    if((!strncmp(pHttpCtx->session[con_fd].uri, "/ndex.html", 11)) || 
       (!strncmp(pHttpCtx->session[con_fd].uri, "/", 1))) {

      http_process_login_req(response_ptr, response_len_ptr);
    }
    fprintf(stderr, "\n%s:%d Unknown URI is received %s\n", 
                    __FILE__,
                    __LINE__,
                    pHttpCtx->session[con_fd].uri);
  }

  return(0);

}/*http_process_uri*/
                          
int32_t http_process_req(uint32_t con_fd, 
                         uint8_t *packet_ptr, 
                         uint16_t packet_length) {

  /*Build temporary HTTP Response*/
  uint8_t *http_ptr = NULL;
  uint16_t http_len = 0;
  int32_t ret = -1;

  http_ctx_t *pHttpCtx = &g_http_ctx;

  fprintf(stderr, "\n%s:%d Received Req is \n%s\n", __FILE__, __LINE__, packet_ptr);
  ret = http_parse_req(con_fd, packet_ptr, packet_length);

  if(ret) {
    fprintf(stderr, "\n%s:%d Connection is being closed\n", __FILE__, __LINE__);
    return(ret);
  }

  http_process_uri(con_fd, &http_ptr, &http_len);

  if(http_send(con_fd, http_ptr, http_len) < 0) {
    perror("redir send Failed:");
    return(-1); 
  }

  free(http_ptr);
  http_ptr = NULL;

  return(0);

}/*http_process_req*/

int32_t http_init(uint32_t uam_ip, 
                  uint16_t uam_port) {

  int32_t fd = -1;
  struct sockaddr_in http_addr;
  size_t http_addr_len;
  http_ctx_t *pHttpCtx = &g_http_ctx;

  fd = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
  if(fd < 0) {
    fprintf(stderr, "\n%s:%d creation of socket failed\n", __FILE__, __LINE__);
    return(-1);
  }
  http_addr_len = sizeof(struct sockaddr_in);
  http_addr.sin_addr.s_addr = htonl(uam_ip);
  http_addr.sin_port = htons(uam_port);
  http_addr.sin_family = AF_INET;
  memset((void *)http_addr.sin_zero, 0, sizeof(http_addr.sin_zero));

  if(bind(fd, (struct sockaddr *)&http_addr, http_addr_len) < 0) {
    fprintf(stderr, "\n%s:%d bind to given address failed\n", __FILE__, __LINE__);
    perror("Bind Failed: ");
    return(-1);
  }
  
  /*Max Pending connection which is 10 as of now*/
  if(listen(fd, 10) < 0) {
    fprintf(stderr, "\n%s:%d listen to given ip failed\n", __FILE__, __LINE__);
    return(-1);
  }

  pHttpCtx->uam_ip = uam_ip;
  pHttpCtx->uam_port = uam_port;
  pHttpCtx->uam_fd = fd;

  memset((void *)pHttpCtx->session, 0, sizeof(pHttpCtx->session));
  pHttpCtx->session_count = 0;

  return(0); 
}/*http_init*/

/* @brief This function is the entry point of thread for Redirect
 *
 * @param1 pointer to void received while spawning the thread.
 *
 * @return pointer to void
 */
void *http_main(void *argv) {

  http_ctx_t *pHttpCtx = &g_http_ctx;
  int32_t ret;
  int32_t new_conn;
  struct timeval to;
  struct sockaddr_in peer_addr;
  uint16_t idx;
  size_t peer_addr_len;
  uint8_t packet_buffer[3000];
  uint16_t packet_length;
  
  for(;;) {
    to.tv_sec = 2;
    to.tv_usec = 0;
    
    FD_ZERO(&pHttpCtx->rd);
    FD_SET(pHttpCtx->uam_fd, &pHttpCtx->rd);

    for(idx = 0; idx < pHttpCtx->session_count; idx++) {
      FD_SET(pHttpCtx->session[idx].conn, &pHttpCtx->rd);
    } 
   
    pHttpCtx->max_fd = (pHttpCtx->uam_fd > pHttpCtx->session[0].conn ? 
                         pHttpCtx->uam_fd : 
                         pHttpCtx->session[0].conn) + 1;

    ret = select(pHttpCtx->max_fd, &pHttpCtx->rd, NULL, NULL, &to);
   
    if(ret > 0) {
      if(FD_ISSET(pHttpCtx->uam_fd, &pHttpCtx->rd)) {
        /*New Connection accept it.*/
        new_conn = accept(pHttpCtx->uam_fd, 
                          (struct sockaddr *)&peer_addr, 
                          (socklen_t *)&peer_addr_len);

        pHttpCtx->session[pHttpCtx->session_count].peer_addr = peer_addr;
        pHttpCtx->session[pHttpCtx->session_count++].conn = new_conn;
        http_quick_sort(pHttpCtx->session, 
                         (int16_t)0, 
                         (int16_t)(pHttpCtx->session_count - 1));
      } else {
        for(idx = 0; idx < pHttpCtx->session_count; idx++) {
          if(FD_ISSET(pHttpCtx->session[idx].conn, &pHttpCtx->rd)) {
            /*Either connection is closed or data has been received.*/
            memset((void *)packet_buffer, 0, sizeof(packet_buffer));
            packet_length = 0;
            http_recv(pHttpCtx->session[idx].conn, packet_buffer, &packet_length);

            if(!packet_length) {
              /*Closing the connected conn_id*/
              close(pHttpCtx->session[idx].conn);
              pHttpCtx->session[idx].conn = 0;

              http_quick_sort(pHttpCtx->session, 
                               (int16_t)0, 
                               (int16_t)(pHttpCtx->session_count - 1));

              http_modify_conn_count(pHttpCtx->session);

            } else {

              if(1 == http_process_req(pHttpCtx->session[idx].conn, 
                                       packet_buffer, 
                                       packet_length)) {
                /*Closing the connected conn_id*/
                close(pHttpCtx->session[idx].conn);
                pHttpCtx->session[idx].conn = 0;

                http_quick_sort(pHttpCtx->session,
                                (int16_t)0,
                                (int16_t)(pHttpCtx->session_count - 1));
                http_modify_conn_count(pHttpCtx->session);
              }
            }
          }  
        }
      }
    } else if(!ret) {
      //fprintf(stderr, "\n%s:%d Got the timeout\n", __FILE__, __LINE__);
    }
  }
  
}/*http_main*/

#endif /* __HTTP_C__ */
