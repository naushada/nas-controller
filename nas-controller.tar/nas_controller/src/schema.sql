
CREATE TABLE IF NOT EXISTS dhcp_conf_table (interface_name TEXT, ip_address TEXT, CIDR TEXT, host_name TEXT, network_id TEXT, host_id_start TEXT, host_id_end);

CREATE TABLE IF NOT EXISTS dhcp_generic_param_table (domain_name TEXT, dns1 TEXT, dns2 TEXT, ns1 TEXT, ns2 TEXT, router_ip_address TEXT, router_subnet_mask TEXT, timer_server_ip TEXT, NTP_server_ip TEXT, lease TEXT, mtu TEXT);

CREATE TABLE IF NOT EXISTS dhcp_ip_allocation (host_name TEXT, mac_address TEXT, network_id TEXT, host_id TEXT, ip_allocation_status TEXT);

CREATE TABLE IF NOT EXISTS dhcp_subscriber_stats (ip_address TEXT, mac_address TEXT, ip_allocation_ts TEXT, ip_released_ts TEXT);

CREATE TABLE IF NOT EXISTS nat_cache_table (src_ip TEXT, src_mac TEXT, src_port TEXT, dest_ip TEXT, dest_port TEXT);

CREATE TABLE IF NOT EXISTS subscriber_authentication_table (ip_address TEXT, dest_port TEXT, uri TEXT, auth_state TEXT);

CREATE TABLE IF NOT EXISTS service_conf_table (ip_address TEXT, port TEXT, service_type TEXT);



INSERT INTO dhcp_conf_table (interface_name, ip_address, CIDR, host_name, network_id, host_id_start, host_id_end) VALUES ('eth0', '10.100.16.1', '20', '', '10.100.16', '2', '');

INSERT INTO dhcp_generic_param_table (domain_name, dns1, dns2, ns1, ns2, router_ip_address, router_subnet_mask, timer_server_ip, NTP_server_ip, lease, mtu) VALUES ('balaagh.com', '8.8.8.8', '8.8.4.4', '10.100.16.1', '', '10.100.16.1', '255.255.240.0', '', '', '7', '1500');


INSERT INTO service_conf_table (ip_address, port, service_type) VALUES ('10.100.16.1', '8080', 'UAM_SERVER');
INSERT INTO service_conf_table (ip_address, port, service_type) VALUES ('10.100.16.1', '8080', 'RADIUS_SERVER');
